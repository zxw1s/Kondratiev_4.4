import * as universal from "../../../../src/routes/sverdle/how-to-play/+page.js";
export { universal };
export { default as component } from "../../../../src/routes/sverdle/how-to-play/+page.svelte";