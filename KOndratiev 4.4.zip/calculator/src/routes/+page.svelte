<script>
  let input = "";
  let result = "";

  function calculate() {
    try {
      result = eval(input);
    } catch {
      result = "Ошибка";
    }
  }

  function clear() {
    input = "";
    result = "";
  }

  function inputChar(char) {
    input += char;
  }
</script>

<style>
  .calculator {
    display: grid;
    gap: 10px;
    grid-template-columns: repeat(4, 1fr);
    max-width: 300px;
  }

  button {
    padding: 10px;
    font-size: 18px;
  }

  input {
    grid-column: span 4;
    padding: 10px;
    font-size: 18px;
  }

  .result {
    grid-column: span 4;
    padding: 10px;
    background-color: #f0f0f0;
    font-size: 18px;
  }
</style>

<div class="calculator">
  <input type="text" bind:value={input} />
  <div class="result">{result}</div>
  <button on:click={() => inputChar('1')}>1</button>
  <button on:click={() => inputChar('2')}>2</button>
  <button on:click={() => inputChar('3')}>3</button>
  <button on:click={() => inputChar('+')}>+</button>
  <button on:click={() => inputChar('4')}>4</button>
  <button on:click={() => inputChar('5')}>5</button>
  <button on:click={() => inputChar('6')}>6</button>
  <button on:click={() => inputChar('-')}>-</button>
  <button on:click={() => inputChar('7')}>7</button>
  <button on:click={() => inputChar('8')}>8</button>
  <button on:click={() => inputChar('9')}>9</button>
  <button on:click={() => inputChar('*')}>*</button>
  <button on:click={clear}>C</button>
  <button on:click={() => inputChar('0')}>0</button>
  <button on:click={() => inputChar('.')}>.</button>
  <button on:click={() => inputChar('/')}>/</button>
  <button on:click={calculate}>=</button>
</div>
